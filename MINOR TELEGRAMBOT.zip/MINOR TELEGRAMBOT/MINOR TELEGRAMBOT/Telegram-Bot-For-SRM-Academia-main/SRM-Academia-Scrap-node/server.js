require('dotenv').config();
const express = require('express');
const cors = require('cors');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const axios = require('axios');

const app = express();
const port = process.env.PORT || 9000;

// Middleware
app.use(cors());
app.use(compression());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 500 // limit each IP to 500 requests per windowMs
});
app.use(limiter);

// Helper function to get CSRF token
async function getFreshTokens() {
  try {
    const response = await axios.get(`${process.env.API_ENDPOINT}/accounts/signin`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });
    
    const cookies = response.headers['set-cookie'];
    const csrfToken = cookies.find(cookie => cookie.includes('iamcsr='))?.split(';')[0]?.split('=')[1];
    
    if (!csrfToken) {
      throw new Error('Failed to get CSRF token');
    }
    
    return {
      cookies: cookies.join('; '),
      csrfToken: csrfToken
    };
  } catch (error) {
    console.error('Error fetching tokens:', error.response?.data || error.message);
    throw error;
  }
}

// Routes
app.post('/login', async (req, res) => {
  try {
    const { account, password } = req.body;
    if (!account || !password) {
      return res.status(400).json({ error: 'Missing account or password' });
    }

    // Get fresh tokens
    const { cookies, csrfToken } = await getFreshTokens();
    
    // Perform login lookup
    const user = account.replace("@srmist.edu.in", "");
    const lookupUrl = `${process.env.API_ENDPOINT}/accounts/signin/v2/lookup/${user}@srmist.edu.in`;
    
    const lookupResponse = await axios({
      method: "POST",
      url: lookupUrl,
      headers: {
        Accept: "*/*",
        "Accept-Language": "en-US,en;q=0.9",
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
        "sec-ch-ua": '"Not(A:Brand";v="99", "Google Chrome";v="133", "Chromium";v="133"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "x-zcsrf-token": csrfToken,
        cookie: cookies,
        Referer: `${process.env.API_ENDPOINT}/accounts/signin`,
        "Referrer-Policy": "strict-origin-when-cross-origin",
      },
      data: `mode=primary&cli_time=${Date.now()}&servicename=ZohoCreator&service_language=en&serviceurl=${encodeURIComponent(`${process.env.API_ENDPOINT}/portal/academia-academic-services/redirectFromLogin`)}`,
    });

    if (lookupResponse.data.errors && lookupResponse.data.errors.length > 0) {
      return res.status(401).json({ error: lookupResponse.data.errors[0].message });
    }

    const lookup = lookupResponse.data.lookup;
    if (!lookup) {
      return res.status(401).json({ error: "Invalid credentials" });
    }

    // Perform password authentication
    const sessionResponse = await axios({
      method: "POST",
      url: `${process.env.API_ENDPOINT}/accounts/signin/v2/primary/${lookup.identifier}/password?digest=${lookup.digest}&cli_time=${Date.now()}&servicename=ZohoCreator&service_language=en&serviceurl=${encodeURIComponent(`${process.env.API_ENDPOINT}/portal/academia-academic-services/redirectFromLogin`)}`,
      headers: {
        accept: "*/*",
        "content-type": "application/json",
        "x-zcsrf-token": csrfToken,
        cookie: cookies,
        Referer: `${process.env.API_ENDPOINT}/accounts/signin`,
      },
      data: JSON.stringify({ passwordauth: { password } }),
    });

    if (sessionResponse.data.errors && sessionResponse.data.errors.length > 0) {
      return res.status(401).json({ error: sessionResponse.data.errors[0].message });
    }

    // Get session cookies
    const sessionCookies = sessionResponse.headers['set-cookie'];
    if (!sessionCookies) {
      return res.status(401).json({ error: "No session cookies received" });
    }

    res.json({
      success: true,
      token: sessionCookies.join('; '),
      csrfToken: csrfToken,
      message: "Login successful"
    });

  } catch (error) {
    console.error('Login error:', error.response?.data || error.message);
    res.status(500).json({ error: error.message });
  }
});

app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

// Start server
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
}); 