const axios = require("axios");
const API_ENDPOINT = process.env.API_ENDPOINT || 'https://academia.srmist.edu.in';

async function getFreshTokens() {
  try {
    const response = await axios.get(`${API_ENDPOINT}/srm_university/accounts/signin`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });
    
    const cookies = response.headers['set-cookie'];
    const csrfToken = cookies.find(cookie => cookie.includes('iamcsr='))?.split(';')[0]?.split('=')[1];
    
    if (!csrfToken) {
      console.error('No CSRF token found in cookies:', cookies);
      throw new Error('Failed to get CSRF token');
    }
    
    return {
      cookies: cookies.join('; '),
      csrfToken: csrfToken
    };
  } catch (error) {
    console.error('Error fetching fresh tokens:', error.response?.data || error.message);
    throw error;
  }
}

async function login(username, password) {
  const user = username.replace("@srmist.edu.in", "");
  const url = `${API_ENDPOINT}/srm_university/accounts/signin/v2/lookup/${user}@srmist.edu.in`;

  try {
    // Get fresh tokens
    const { cookies, csrfToken } = await getFreshTokens();
    console.log('Got fresh tokens:', { csrfToken: csrfToken.substring(0, 10) + '...' });
    
    const lookupResponse = await axios({
      method: "POST",
      url: url,
      headers: {
        Accept: "*/*",
        "Accept-Language": "en-US,en;q=0.9",
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
        "sec-ch-ua": '"Not(A:Brand";v="99", "Google Chrome";v="133", "Chromium";v="133"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "x-zcsrf-token": csrfToken,
        cookie: cookies,
        Referer: `${API_ENDPOINT}/srm_university/accounts/signin`,
        "Referrer-Policy": "strict-origin-when-cross-origin",
      },
      data: `mode=primary&cli_time=${Date.now()}&servicename=ZohoCreator&service_language=en&serviceurl=${encodeURIComponent(`${API_ENDPOINT}/portal/academia-academic-services/redirectFromLogin`)}`,
    });

    console.log('Lookup response:', lookupResponse.data);

    const data = lookupResponse.data;

    if (data.errors && data.errors.length > 0) {
      const lookupMsg = data.errors[0].message;
      const statusCode = data.status_code;

      if (statusCode === 400) {
        return {
          authenticated: false,
          session: null,
          lookup: null,
          cookies: "",
          status: statusCode,
          message: data.message?.includes("HIP")
            ? ">_ Captcha required, We don't support yet"
            : data.message,
          errors: [lookupMsg],
        };
      }
    }

    const exists = data.message && data.message.includes("User exists");

    if (!exists) {
      return {
        authenticated: false,
        session: null,
        lookup: null,
        cookies: "",
        status: data.status_code,
        message: data.message?.includes("HIP")
          ? data.localized_message
          : data.message,
        errors: null,
      };
    }

    const lookup = data.lookup;
    if (!lookup) {
      throw new Error("Invalid lookup data");
    }

    const session = await getSession(password, lookup);

    const sessionBody = {
      success: true,
      code: session.passwordauth?.code,
      message: session.message,
    };

    if (
      session.message.toLowerCase().includes("invalid") ||
      session.cookies.includes("undefined")
    ) {
      sessionBody.success = false;
      return {
        authenticated: false,
        session: sessionBody,
        lookup: {
          identifier: lookup.identifier,
          digest: lookup.digest,
        },
        cookies: session.cookies,
        status: data.status_code,
        message: session.message,
        errors: null,
      };
    }

    return {
      authenticated: true,
      session: sessionBody,
      lookup: lookup,
      cookies: session.cookies,
      status: data.status_code,
      message: data.message,
      errors: null,
    };
  } catch (error) {
    console.error("Login error:", error.response?.data || error.message);
    throw error;
  }
}

async function getSession(password, lookup) {
  const { identifier, digest } = lookup;
  const body = JSON.stringify({ passwordauth: { password } });

  try {
    // Get fresh tokens for the session request
    const { cookies, csrfToken } = await getFreshTokens();
    console.log('Got fresh tokens for session:', { csrfToken: csrfToken.substring(0, 10) + '...' });
    
    const response = await axios({
      method: "POST",
      url: `${API_ENDPOINT}/srm_university/accounts/signin/v2/primary/${identifier}/password?digest=${digest}&cli_time=${Date.now()}&servicename=ZohoCreator&service_language=en&serviceurl=${encodeURIComponent(`${API_ENDPOINT}/portal/academia-academic-services/redirectFromLogin`)}`,
      headers: {
        accept: "*/*",
        "content-type": "application/json",
        "x-zcsrf-token": csrfToken,
        cookie: cookies,
        Referer: `${API_ENDPOINT}/srm_university/accounts/signin`,
      },
      data: body,
    });

    console.log('Session response:', response.data);

    const data = response.data;

    let cookiesHeader = "";
    if (response.headers["set-cookie"]) {
      if (Array.isArray(response.headers["set-cookie"])) {
        cookiesHeader = response.headers["set-cookie"].join("; ");
      } else {
        cookiesHeader = response.headers["set-cookie"];
      }
    }

    data.cookies = cookiesHeader;
    return data;
  } catch (error) {
    console.error("Session error:", error.response?.data || error.message);
    throw error;
  }
}

async function logout(token) {
  try {
    const response = await axios({
      method: "POST",
      url: `${API_ENDPOINT}/accounts/logout`,
      headers: {
        Accept: "*/*",
        "Content-Type": "application/x-www-form-urlencoded",
        Cookie: token,
      },
    });

    return {
      success: true,
      message: "Successfully logged out",
      status: response.status,
    };
  } catch (error) {
    console.error("Logout error:", error);
    return {
      success: false,
      message: error.message || "Failed to logout",
      status: error.response?.status || 500,
    };
  }
}

module.exports = {
  login,
  logout,
  getSession,
};
