const axios = require('axios');
const config = require('../config/config')

/**
 * Make authenticated API requests
 * @param {string} endpoint - API endpoint to call
 * @param {Object} session - User session with authentication tokens
 * @param {string} method - HTTP method (default: 'get')
 * @param {Object} data - Request payload for POST/PUT requests
 * @returns {Promise} Axios request promise
 */
async function makeAuthenticatedRequest(endpoint, session, method = 'get', data = null) {
  const url = `${config.API_BASE_URL}${endpoint}`;
  
  const headers = {
    'Authorization': `Bearer ${session.token}`,
    'X-CSRF-Token': session.csrfToken,
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  };
  
  switch (method.toLowerCase()) {
    case 'post':
      return axios.post(url, data, { headers });
    case 'put':
      return axios.put(url, data, { headers });
    case 'delete':
      return axios.delete(url, { headers });
    default:
      return axios.get(url, { headers });
  }
}

/**
 * Login to SRM API
 * @param {string} account - Username or registration number
 * @param {string} password - User password
 * @returns {Promise} Axios request promise
 */
async function login(account, password) {
  try {
    // First get fresh tokens
    const tokenResponse = await axios.get(`${config.API_BASE_URL}/srm_university/accounts/signin`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });
    
    const cookies = tokenResponse.headers['set-cookie'];
    const csrfToken = cookies.find(cookie => cookie.includes('iamcsr='))?.split(';')[0]?.split('=')[1];
    
    if (!csrfToken) {
      throw new Error('Failed to get CSRF token');
    }

    // Then perform login
    const user = account.replace("@srmist.edu.in", "");
    const url = `${config.API_BASE_URL}/srm_university/accounts/signin/v2/lookup/${user}@srmist.edu.in`;
    
    const lookupResponse = await axios({
      method: "POST",
      url: url,
      headers: {
        Accept: "*/*",
        "Accept-Language": "en-US,en;q=0.9",
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
        "sec-ch-ua": '"Not(A:Brand";v="99", "Google Chrome";v="133", "Chromium";v="133"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "x-zcsrf-token": csrfToken,
        cookie: cookies.join('; '),
        Referer: `${config.API_BASE_URL}/srm_university/accounts/signin`,
        "Referrer-Policy": "strict-origin-when-cross-origin",
      },
      data: `mode=primary&cli_time=${Date.now()}&servicename=ZohoCreator&service_language=en&serviceurl=${encodeURIComponent(`${config.API_BASE_URL}/portal/academia-academic-services/redirectFromLogin`)}`,
    });

    console.log('Login response:', lookupResponse.data);
    return lookupResponse;
  } catch (error) {
    console.error('Login error:', error.response ? error.response.data : error.message);
    throw error;
  }
}

/**
 * Logout from SRM API
 * @param {Object} session - User session with authentication tokens
 * @returns {Promise} Axios request promise
 */
async function logout(session) {
  return makeAuthenticatedRequest('/logout', session, 'delete');
}

module.exports = {
  makeAuthenticatedRequest,
  login,
  logout
};